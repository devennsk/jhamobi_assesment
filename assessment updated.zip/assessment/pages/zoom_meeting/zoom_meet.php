<html>

<head>
    <!-- import #zmmtg-root css -->
    <link type="text/css" rel="stylesheet" href="https://source.zoom.us/1.7.5/css/bootstrap.css" />
    <link type="text/css" rel="stylesheet" href="https://source.zoom.us/1.7.5/css/react-select.css" />
<head>
<body class="ReactModal__Body--open">
    <!-- import ZoomMtg dependencies -->
    <script src="https://source.zoom.us/1.7.5/lib/vendor/react.min.js"></script>
    <script src="https://source.zoom.us/1.7.5/lib/vendor/react-dom.min.js"></script>
    <script src="https://source.zoom.us/1.7.5/lib/vendor/redux.min.js"></script>
    <script src="https://source.zoom.us/1.7.5/lib/vendor/redux-thunk.min.js"></script>
    <script src="https://source.zoom.us/1.7.5/lib/vendor/jquery.min.js"></script>
    <script src="https://source.zoom.us/1.7.5/lib/vendor/lodash.min.js"></script>

    <!-- import ZoomMtg -->
    <script src="https://source.zoom.us/zoom-meeting-1.7.5.min.js"></script>
    
    <!-- import local .js file -->
    <script src="js/index.js"></script>
	

     <!-- added on import -->
    <div id="zmmtg-root"></div>
    <div id="aria-notify-area"></div>
    
    <!-- added on meeting init -->
    <div class="ReactModalPortal"></div>
    <div class="ReactModalPortal"></div>
    <div class="ReactModalPortal"></div>
    <div class="ReactModalPortal"></div>
    <div class="global-pop-up-box"></div>
    <div class="sharer-controlbar-container sharer-controlbar-container--hidden"></div>
	


</body>

</html>