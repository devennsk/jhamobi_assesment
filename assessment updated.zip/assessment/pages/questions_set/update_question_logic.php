<?php
session_start();
if(!isset($_SESSION['userId']) || !isset($_SESSION['userType']))
{
header("Location: ../../login.html");
}
else
{
	include "../../config.php";
	error_reporting(0);
	
	if(isset($_POST['submit']))//for update question set
	{
		$quesSetId=$_POST['quesSetId'];
		$quesSetName=$_POST['quesSetName'];
		$gradeId=$_POST['gradeName'];
		$subjectId=$_POST['subjectName'];
		//$unitsId=$_POST['unitsName'];
		//$chapterId=$_POST['chapterName'];
		
		$res1=mysqli_query($conn,"select * from `grade` where `gradeId`='$gradeId'");
		while($r1=mysqli_fetch_array($res1))
		{	
			$gradeName=$r1['gradeName'];
		}
		
		$res2=mysqli_query($conn,"select * from `subject` where `subjectId`='$subjectId'");
		while($r2=mysqli_fetch_array($res2))
		{	
			$subjectName=$r2['subjectName'];
		}
		
		/*$res3=mysqli_query($conn,"select * from `chapter` where `chapterId`='$chapterId'");
		while($r3=mysqli_fetch_array($res3))
		{	
			$chapterName=$r3['chapterName'];
		}
		
		$res4=mysqli_query($conn,"select * from `subject_units` where `unitsId`='$unitsId'");
		while($r4=mysqli_fetch_array($res4))
		{	
			$unitsName=$r4['unitsName'];
		}*/
		
		$status=$_POST['status'];
		date_default_timezone_set('Asia/Kolkata');
		$date = date('Y-m-d H:i:s');
		
		$createdOn=$date;
		$createdBy=$_SESSION['userType'];
		
		$q_list = $_POST['quesID'];
		$quesCount=count($q_list);
		foreach($q_list as $selected)
		{
			$quesIdList= $selected.",".$quesIdList;
		}
		

		
		$result1=mysqli_query($conn,"UPDATE `questionSet` set `quesSetName`='$quesSetName', `quesCount`='$quesCount', `gradeId`='$gradeId', `gradeName`='$gradeName', 
		`subjectId`='$subjectId', `subjectName`='$subjectName', `topicId`='$unitsId', `topicName`='$unitsName', `chapterId`='$chapterId', `chapterName`='$chapterName', `createdOn`='$createdOn', `createdBy`='$createdBy', `status`='$status', `quesIdList`='$quesIdList' WHERE `quesSetId`='$quesSetId'");
		if(mysqli_affected_rows($conn) > 0)
		{
			echo "<script type='text/javascript'>
			
			window.location.href='http://localhost/assessment/pages/questions_set/view_question_set.php';
			alert('Question Papaer updated successfully.')
			</script>";
		}
		else
		{
			
			echo "<script type='text/javascript'>
			window.location.href='http://localhost/assessment/pages/questions_set/update_question_set.php';
			alert('Something went wrong!')
			</script>";
			
		}
	}
}
?>